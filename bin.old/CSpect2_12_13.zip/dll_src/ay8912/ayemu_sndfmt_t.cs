﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ay8912
{
    public class ayemu_sndfmt_t
    {
        public int freq;        // sound freq 
        public int channels;    // channels (1-mono, 2-stereo) 
        public int bpc;			// bits (8 or 16) */
    }
}
